<?php include('functions.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Aiden Mckay</title> <!-- title for tab -->
	<link rel="stylesheet" type="text/css" href="style.css"> <!-- imports the css file to be used in this file -->
</head>
<body>
	<div class="header"><!-- header for the login ppage -->
		<h2>Login</h2>
	</div>
	<form method="post" action="login.php">

		<?php echo display_error(); ?> <!-- error handling function incase the login credentials arent valid -->

		<div class="input-group"><!-- input section for the login -->
			<label>Username</label>
			<input type="text" name="username" >
		</div>
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password">
		</div>
		<div class="input-group">
			<button type="submit" class="button-style" name="login_btn">Login</button> <!-- login button -->
		</div>
		<p>
			<a href="register.php">Sign up</a> <!-- signup page internal link -->
		</p>
	</form>
</body>
</html>
