<?php
  require('functions.php');
  $choice = $_GET["choice"];

  $choice_query = "INSERT INTO rps (choice)
        VALUES ('$choice')";
  $result = mysqli_query($db, $choice_query);
?>
