

<?php
  require('functions.php');//requires functions.php to connect the database
  $choice = $_GET["choice"]; // this gets the choice from the user

  $choice_query = "INSERT INTO rps (choice)
        VALUES ('$choice')";//this inserts the user choice into the rps table to record which choice they made
  $result = mysqli_query($db, $choice_query); // this gets the variaable results and gives the data bback
?>
