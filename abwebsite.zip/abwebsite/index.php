<?php
include('functions.php');//requires functions allows all the functions to be used by this ppage
if (!isLoggedIn()) {
	$_SESSION['msg'] = "You must log in first";// this checks if the user is not logged in and if they arent it redirects them to the login page
	header('location: login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Aiden Mckay</title> <!-- title for the tab name -->
	<link rel="stylesheet" type="text/css" href="style.css"> <!-- calls css file and scriptp file to be used in this index.php file -->
  <script src="script.js" defer></script>
</head>
<body>
	<div class="header"> <!-- header for the game -->
		<h2>Rock Paper Scissors</h2>
	</div>
	<div class="content">
		<?php if (isset($_SESSION['success'])) :?> <!-- message to display if the user isnt logged in  -->
			<div class="error success" >
				<h3>
					<?php
						echo $_SESSION['success'];
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>
		<div class="profile_info">
			<img src="images/user_profile.png"  >

			<div>
				<?php  if (isset($_SESSION['user'])) : ?> <!-- if statement to check if a user or admion is logged in -->
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i>
						<br>
						<a href="index.php?logout='1'" style="color: red;">logout</a>
					</small> <!-- displays the logged in users name and also a logout button -->

				<?php endif ?>


			</div>
		</div>
    <div class="selections"> <!-- rock paper scissors game input -->
      <button class="selection" data-selection="rock" value="<?php echo $rock; ?>">🧱</button>
      <button class="selection" data-selection="paper" value="<?php echo $paper; ?>">🧾</button>
      <button class="selection" data-selection="scissors"value="<?php echo $scissors; ?>">✂️</button>
    </div>
    <div class="results">
      <div> <!-- rock paper game outpput -->
        <?php echo ucfirst($_SESSION['user']['username']); ?> :
        <span class="final-score-results" data-your-score>0</span>
      </div>
      <div data-final-column>
        Computer :
        <span class="final-score-results" data-computer-score>0</span>
      </div>
      <!-- <div class="result-selection winner">🧱</div>
      <div class="result-selection">✂️</div> -->
    </div>
	</div>
</body>
</html>
