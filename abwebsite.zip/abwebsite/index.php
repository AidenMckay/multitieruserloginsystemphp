<?php
include('functions.php');
if (!isLoggedIn()) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Aiden Mckay</title>
	<link rel="stylesheet" type="text/css" href="style.css">
  <script src="script.js" defer></script>
</head>
<body>
	<div class="header">
		<h2>Rock Paper Scissors</h2>
	</div>
	<div class="content">
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php
						echo $_SESSION['success'];
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>
		<div class="profile_info">
			<img src="images/user_profile.png"  >

			<div>
				<?php  if (isset($_SESSION['user'])) : ?>
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i>
						<br>
						<a href="index.php?logout='1'" style="color: red;">logout</a>
					</small>

				<?php endif ?>


			</div>
		</div>
    <div class="selections">
      <button class="selection" data-selection="rock" value="<?php echo $rock; ?>">🧱</button>
      <button class="selection" data-selection="paper" value="<?php echo $paper; ?>">🧾</button>
      <button class="selection" data-selection="scissors"value="<?php echo $scissors; ?>">✂️</button>
    </div>
    <div class="results">
      <div>
        <?php echo ucfirst($_SESSION['user']['username']); ?> :
        <span class="result-score" data-your-score>0</span>
      </div>
      <div data-final-column>
        Computer :
        <span class="result-score" data-computer-score>0</span>
      </div>
      <!-- <div class="result-selection winner">🧱</div>
      <div class="result-selection">✂️</div> -->
    </div>
	</div>
</body>
</html>
