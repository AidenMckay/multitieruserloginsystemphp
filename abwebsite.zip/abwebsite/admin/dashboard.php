<?php include('../functions.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Aiden Mckay</title>  <!-- This displays the title at the topof the tab -->
	<link rel="stylesheet" type="text/css" href="../style.css"> <!-- this links the css file style.css -->
	<style>
		.header {
			background: darkblue;
		}
		button[name=register_btn] {
			background: skyblue;
		}
	</style><!-- inline styling -->
</head>
<body>
	<div class="header">
		<h2>Admin - Dashboard</h2> <!-- title for the dashboard -->
	</div>
  <div class="content">
    <!-- popup message -->
    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php
            echo $_SESSION['success'];
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>

    <!-- logged in message -->
    <div class="profile_info">
      <img src="../images/admin_profile.png"  >

      <div>
        <?php  if (isset($_SESSION['user'])) : ?> <!-- if statement to check if a user is logged in -->
          <strong><?php echo $_SESSION['user']['username']; ?></strong>

          <small>
            <i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i>
            <br>
            <a href="home.php?logout='1'" style="color: red;">logout</a>
          </small> <!-- dislays the user that is logged in along with a logout buttion -->

        <?php endif ?>
      </div>
    </div>
    <hr>
    <hr>




    <div class="countwrapper">

      <h1> Rock Paper Scissors Results </h1> <!-- this is the rockpaperscissors game uses a class called selections and a datalist to contain them -->
      <div class="selections">
        <dl>
          <dt>🧱</dt>
          <dt>🧾</dt>
          <dt>✂️</dt>

          <dd><?php echo $rock_count; ?></dd> <!-- calls the variales from my scriptp file to the website -->
          <dd><?php echo $paper_count; ?></dd>
          <dd><?php echo $scissors_count; ?></dd>
        </dl>
      </div>
    </div>









































  </div>
</body>
</html>
