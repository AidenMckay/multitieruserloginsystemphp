<?php include('../functions.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Aiden Mckay</title>
	<link rel="stylesheet" type="text/css" href="../style.css">
	<style>
		.header {
			background: darkblue;
		}
		button[name=register_btn] {
			background: skyblue;
		}
	</style>
</head>
<body>
	<div class="header">
		<h2>Admin - Dashboard</h2>
	</div>
  <div class="content">
    <!-- notification message -->
    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php
            echo $_SESSION['success'];
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>

    <!-- logged in user information -->
    <div class="profile_info">
      <img src="../images/admin_profile.png"  >

      <div>
        <?php  if (isset($_SESSION['user'])) : ?>
          <strong><?php echo $_SESSION['user']['username']; ?></strong>

          <small>
            <i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i>
            <br>
            <a href="home.php?logout='1'" style="color: red;">logout</a>
          </small>

        <?php endif ?>
      </div>
    </div>
    <hr>
    <hr>




    <div class="countwrapper">

      <h1> Rock Paper Scissors Results </h1>
      <div class="selections">
        <dl>
          <dt>🧱</dt>
          <dt>🧾</dt>
          <dt>✂️</dt>

          <dd><?php echo $rock_count; ?></dd>
          <dd><?php echo $paper_count; ?></dd>
          <dd><?php echo $scissors_count; ?></dd>
        </dl>
      </div>
    </div>









































  </div>
</body>
</html>
